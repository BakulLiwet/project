# example.py

from my_package.utils import some_function

def main():
    print("Running example script...")
    # result = some_function()
    # print("Result:", result)

if __name__ == "__main__":
    main()